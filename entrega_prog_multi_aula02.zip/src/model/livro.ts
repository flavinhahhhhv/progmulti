export interface livro{
    nome:string;
    autor:string;
    editora:string;
}