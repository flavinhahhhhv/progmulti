import { Component, ViewChild } from '@angular/core';
import { StorageService, Livro } from '../services/storage.service';
import { Platform, ToastController, IonList, IonListHeader } from '@ionic/angular';
 
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
 
  livro: Livro[] = [];
 
  newLivro: Livro = <Livro>{};
 
  @ViewChild('MinhaLista')Lista: IonList;
 
  constructor(private storageService: StorageService, private plt: Platform,
                     private toastController: ToastController) {
    this.plt.ready().then(() => {
      this.loadLivro();
    });
  }
 
  // CREATE
  addLivro() {
    this.newLivro.titulo = Date.now();
    this.newLivro.subtitulo = Date.now();
    this.newLivro.capa = Date.now();
    this.newLivro.editora = Date.now();
    this.newLivro.autor = Date.now();
    this.newLivro.isbn = Date.now();
    this.newLivro.publicacao = Date.now();
    this.newLivro.pagina = Date.now();
    this.newLivro.id = Date.now();
 
    this.storageService.addLivro(this.newLivro).then(livro => {
      this.newLivro = <Livro>{};
      this.showToast('Livro Adicionado')
      this.loadLivro();
    });
  }
 
  // READ
  loadLivro() {
    this.storageService.getLivro().then(livro => {
      this.livro = livro;
    });
  }
 
  // UPDATE
  updateLivro(livro: Livro) {
    livro.titulo = `Modificado: ${livro.titulo}`;
    livro.modified = Date.now();
 
    this.storageService.updateLivro(livro).then(livro => {
      this.showToast('Livro Modificado');
      this.Lista.closeSlidingLivro(); 
      this.loadLivro();
    });
  }
 
  // DELETE
  deleteItem(livro: Livro) {
    this.storageService.deleteLivro(livro.id).then(livro => {
      this.showToast('Livro Removido');
      this.Lista.closeSlidingLivro();
      this.loadLivro();
    });
  }

  async showToast(msg) {
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000
    });
    toast.present();
  }
 
}