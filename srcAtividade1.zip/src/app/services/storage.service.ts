import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
 
export interface Livro {
  id: number,
  titulo:string;
  subtitulo:string;
  capa:string;
  editora:string;
  autor:string;
  isbn:string;
  publicacao:string;
  paginas:string;
}
 
const LIVROS_KEY = 'my-livros';
 
@Injectable({
  providedIn: 'root'
})
export class StorageService {
 
  constructor(private storage: Storage) { }
 
  // CREATE
  addLivro(livro: Livro): Promise<any> {
    return this.storage.get(LIVROS_KEY).then((items: Livro[]) => {
      if (livro) {
        items.push(livro);
        return this.storage.set(LIVROS_KEY, livro);
      } else {
        return this.storage.set(LIVROS_KEY, [livro]);
      }
    });
  }
 
  // READ
  getLivro(): Promise<Livro[]> {
    return this.storage.get(LIVROS_KEY);
  }
 
  // UPDATE
  updateLivro(livro: Livro): Promise<any> {
    return this.storage.get(LIVROS_KEY).then((livro: Livro[]) => {
      if (!livro || livro.length === 0) {
        return null;
      }
 
      let newLivro: Livro[] = [];
 
      for (let i of livro) {
        if (i.id === livro.id) {
          newLivro.push(livro);
        } else {
          newLivro.push(i);
        }
      }
 
      return this.storage.set(LIVROS_KEY, newLivro);
    });
  }
 
  // DELETE
  deleteLivro(id: number): Promise<Livro> {
    return this.storage.get(LIVROS_KEY).then((livro: Livro[]) => {
      if (!livro || livro.length === 0) {
        return null;
      }
 
      let toKeep: Livro[] = [];
 
      for (let i of livro) {
        if (i.id !== id) {
          toKeep.push(i);
        }
      }
      return this.storage.set(LIVROS_KEY, toKeep);
    });
  }
}