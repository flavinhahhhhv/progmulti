export interface livro{
    nome:string;
    autor:string;
}